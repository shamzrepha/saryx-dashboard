package com.example.deliveryrobot

import android.content.Context
import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import org.webrtc.*

/*
  Publishes the phone's camera as a low-res, low-bitrate, real-time WebRTC stream,
  matching the signaling schema the web dashboard's useRobotStream.js hook expects:
    calls/robot-stream (doc)             <- offer/answer written here
    calls/robot-stream/offerCandidates   <- this device's ICE candidates
    calls/robot-stream/answerCandidates  <- dashboard's ICE candidates (we listen)

  Forces a pure SOFTWARE video encoder (VP8) - many phones (especially MediaTek-based,
  e.g. Tecno/Transsion devices) have a broken/incompatible hardware H264 encoder path
  that produces black frames over WebRTC while local preview (which bypasses the
  encoder) looks fine. Software encoding costs more CPU/battery but is reliable.

  Bitrate capped low intentionally (~250kbps) - real-time responsiveness over image
  quality, per what this robot actually needs for driving/streaming.
*/
class WebRtcPublisher(private val context: Context) {

    private val TAG = "WebRtcPublisher"
    private val firestore = FirebaseFirestore.getInstance()
    private val callDocRef = firestore.collection("calls").document("robot-stream")

    private lateinit var eglBase: EglBase
    private lateinit var peerConnectionFactory: PeerConnectionFactory
    private var peerConnection: PeerConnection? = null
    private var videoCapturer: VideoCapturer? = null
    var localVideoTrack: VideoTrack? = null
        private set
    val openCvAnalyzer = OpenCvAnalyzer()

    private val iceServers = listOf(
        PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
        PeerConnection.IceServer.builder("turn:openrelay.metered.ca:80")
            .setUsername("openrelayproject").setPassword("openrelayproject").createIceServer(),
        PeerConnection.IceServer.builder("turn:openrelay.metered.ca:80?transport=tcp")
            .setUsername("openrelayproject").setPassword("openrelayproject").createIceServer(),
        PeerConnection.IceServer.builder("turn:openrelay.metered.ca:443")
            .setUsername("openrelayproject").setPassword("openrelayproject").createIceServer(),
        PeerConnection.IceServer.builder("turn:openrelay.metered.ca:443?transport=tcp")
            .setUsername("openrelayproject").setPassword("openrelayproject").createIceServer(),
        PeerConnection.IceServer.builder("turns:openrelay.metered.ca:443?transport=tcp")
            .setUsername("openrelayproject").setPassword("openrelayproject").createIceServer()
    )

    fun start() {
        eglBase = EglBase.create()
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(context)
                .setEnableInternalTracer(true)
                .createInitializationOptions()
        )

        // Pure software encoder - see class doc comment for why. This ONLY supports
        // VP8/VP9 (no H264), so the SDP offer will only list those codecs.
        val encoderFactory = SoftwareVideoEncoderFactory()
        val decoderFactory = DefaultVideoDecoderFactory(eglBase.eglBaseContext)

        peerConnectionFactory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(encoderFactory)
            .setVideoDecoderFactory(decoderFactory)
            .createPeerConnectionFactory()

        startCapture()
        createPeerConnectionAndOffer()
        listenForAnswerAndIce()
    }

    private fun startCapture() {
        val videoSource = peerConnectionFactory.createVideoSource(false)
        val surfaceHelper = SurfaceTextureHelper.create("CaptureThread", eglBase.eglBaseContext)

        videoCapturer = createCameraCapturer()
        if (videoCapturer == null) {
            Log.e(TAG, "No camera capturer could be created - check camera permission was granted")
            return
        }

        videoCapturer?.initialize(surfaceHelper, context, videoSource.capturerObserver)
        videoCapturer?.startCapture(320, 240, 15)
        Log.i(TAG, "Camera capture started: 320x240 @ 15fps")

        localVideoTrack = peerConnectionFactory.createVideoTrack("robot_video_track", videoSource)
        localVideoTrack?.setEnabled(true)
        localVideoTrack?.addSink(openCvAnalyzer)
        localVideoTrack?.addSink(object : VideoSink {
            private var loggedFirstFrame = false
            override fun onFrame(frame: VideoFrame) {
                if (!loggedFirstFrame) {
                    Log.i(TAG, "First local frame captured: ${frame.rotatedWidth}x${frame.rotatedHeight}")
                    loggedFirstFrame = true
                }
            }
        })
    }

    private fun createCameraCapturer(): VideoCapturer? {
        val enumerator = Camera2Enumerator(context)
        for (deviceName in enumerator.deviceNames) {
            if (enumerator.isBackFacing(deviceName)) {
                enumerator.createCapturer(deviceName, null)?.let { return it }
            }
        }
        enumerator.deviceNames.firstOrNull()?.let {
            return enumerator.createCapturer(it, null)
        }
        return null
    }

    private fun createPeerConnectionAndOffer() {
        val rtcConfig = PeerConnection.RTCConfiguration(iceServers)
        rtcConfig.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN

        peerConnection = peerConnectionFactory.createPeerConnection(rtcConfig, object : PeerConnection.Observer {
            override fun onIceCandidate(candidate: IceCandidate) {
                val map = hashMapOf(
                    "sdpMid" to candidate.sdpMid,
                    "sdpMLineIndex" to candidate.sdpMLineIndex,
                    "candidate" to candidate.sdp
                )
                callDocRef.collection("offerCandidates").add(map)
            }
            override fun onSignalingChange(state: PeerConnection.SignalingState) {
                Log.i(TAG, "Signaling state: $state")
            }
            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState) {
                Log.i(TAG, "ICE connection state: $state")
            }
            override fun onIceConnectionReceivingChange(receiving: Boolean) {}
            override fun onIceGatheringChange(state: PeerConnection.IceGatheringState) {
                Log.i(TAG, "ICE gathering state: $state")
            }
            override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>) {}
            override fun onAddStream(stream: MediaStream) {}
            override fun onRemoveStream(stream: MediaStream) {}
            override fun onDataChannel(channel: DataChannel) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(receiver: RtpReceiver, streams: Array<out MediaStream>) {}
            override fun onConnectionChange(newState: PeerConnection.PeerConnectionState) {
                Log.i(TAG, "Peer connection state: $newState")
            }
        })

        val streamIds = listOf("robot_stream")
        val sender = localVideoTrack?.let { peerConnection?.addTrack(it, streamIds) }

        // Cap bitrate - real-time and low-data over image quality, as intended
        sender?.let {
            val params = it.parameters
            if (params.encodings.isNotEmpty()) {
                params.encodings[0].maxBitrateBps = 250_000
                it.parameters = params
            }
        }

        val constraints = MediaConstraints()
        peerConnection?.createOffer(object : SdpObserverAdapter("createOffer") {
            override fun onCreateSuccess(desc: SessionDescription?) {
                if (desc == null) {
                    Log.e(TAG, "createOffer succeeded but description was null")
                    return
                }
                peerConnection?.setLocalDescription(SdpObserverAdapter("setLocalDescription"), desc)
                val offerMap = hashMapOf("type" to desc.type.canonicalForm(), "sdp" to desc.description)
                callDocRef.set(mapOf("offer" to offerMap))
                    .addOnSuccessListener { Log.i(TAG, "Offer written to Firestore successfully") }
                    .addOnFailureListener { e -> Log.e(TAG, "Failed to write offer to Firestore", e) }
            }
        }, constraints)
    }

    private fun listenForAnswerAndIce() {
        callDocRef.addSnapshotListener { snapshot, error ->
            if (error != null) {
                Log.e(TAG, "Firestore listener error on call doc", error)
                return@addSnapshotListener
            }
            val data = snapshot?.data ?: return@addSnapshotListener
            val answerMap = data["answer"] as? Map<*, *> ?: return@addSnapshotListener
            if (peerConnection?.remoteDescription == null) {
                Log.i(TAG, "Answer received from dashboard - setting remote description")
                val desc = SessionDescription(
                    SessionDescription.Type.ANSWER,
                    answerMap["sdp"] as String
                )
                peerConnection?.setRemoteDescription(SdpObserverAdapter("setRemoteDescription"), desc)
            }
        }

        callDocRef.collection("answerCandidates").addSnapshotListener { snapshot, error ->
            if (error != null) {
                Log.e(TAG, "Firestore listener error on answerCandidates", error)
                return@addSnapshotListener
            }
            snapshot?.documentChanges?.forEach { change ->
                if (change.type == com.google.firebase.firestore.DocumentChange.Type.ADDED) {
                    val d = change.document
                    val candidate = IceCandidate(
                        d.getString("sdpMid"),
                        (d.getLong("sdpMLineIndex") ?: 0L).toInt(),
                        d.getString("candidate")
                    )
                    peerConnection?.addIceCandidate(candidate)
                }
            }
        }
    }

    fun stop() {
        videoCapturer?.stopCapture()
        videoCapturer?.dispose()
        peerConnection?.close()
    }

    /** Call after start() to show the local camera feed on-screen. Safe to call even
     *  if you never connect to a dashboard viewer - purely local preview. */
    fun attachLocalRenderer(renderer: org.webrtc.SurfaceViewRenderer) {
        renderer.init(eglBase.eglBaseContext, null)
        localVideoTrack?.addSink(renderer)
    }
}

/** SdpObserver with logging so createOffer/setLocalDescription/setRemoteDescription
 *  failures are visible in Logcat instead of silently swallowed. */
open class SdpObserverAdapter(private val label: String = "SdpObserver") : SdpObserver {
    override fun onCreateSuccess(desc: SessionDescription?) {}
    override fun onSetSuccess() {
        Log.i("WebRtcPublisher", "$label: set succeeded")
    }
    override fun onCreateFailure(error: String?) {
        Log.e("WebRtcPublisher", "$label: create failed - $error")
    }
    override fun onSetFailure(error: String?) {
        Log.e("WebRtcPublisher", "$label: set failed - $error")
    }
}

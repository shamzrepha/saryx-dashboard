package com.example.deliveryrobot

import android.content.Context
import com.google.firebase.firestore.FirebaseFirestore
import org.webrtc.*

/*
  Publishes the phone's camera as a low-res, low-bitrate WebRTC stream, matching
  the signaling schema the web dashboard's useRobotStream.js hook expects:
    calls/robot-stream (doc)         <- offer/answer written here
    calls/robot-stream/offerCandidates   <- this device's ICE candidates
    calls/robot-stream/answerCandidates  <- dashboard's ICE candidates (we listen)

  Gradle dependency needed:
    implementation("io.getstream:stream-webrtc-android:1.1.1")
    (or org.webrtc:google-webrtc:1.0.+ if you prefer Google's own artifact - package
    names are the same either way, `org.webrtc.*`)

  Resolution/bitrate kept low intentionally (see startCapture) for latency + data use.
*/
class WebRtcPublisher(private val context: Context) {

    private val firestore = FirebaseFirestore.getInstance()
    private val callDocRef = firestore.collection("calls").document("robot-stream")

    private lateinit var eglBase: EglBase
    private lateinit var peerConnectionFactory: PeerConnectionFactory
    private var peerConnection: PeerConnection? = null
    private var videoCapturer: VideoCapturer? = null
    var localVideoTrack: VideoTrack? = null
        private set
    val openCvAnalyzer = OpenCvAnalyzer()

    private val iceServers = listOf(
        PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
        PeerConnection.IceServer.builder("turn:openrelay.metered.ca:80")
            .setUsername("openrelayproject").setPassword("openrelayproject").createIceServer(),
        PeerConnection.IceServer.builder("turn:openrelay.metered.ca:443")
            .setUsername("openrelayproject").setPassword("openrelayproject").createIceServer()
    )

    fun start() {
        eglBase = EglBase.create()
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(context).createInitializationOptions()
        )
        val encoderFactory = SoftwareVideoEncoderFactory()
        val decoderFactory = DefaultVideoDecoderFactory(eglBase.eglBaseContext)
        peerConnectionFactory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(encoderFactory)
            .setVideoDecoderFactory(decoderFactory)
            .createPeerConnectionFactory()

        startCapture()
        createPeerConnectionAndOffer()
        listenForAnswerAndIce()
    }

    private fun startCapture() {
        val videoSource = peerConnectionFactory.createVideoSource(false)
        val surfaceHelper = SurfaceTextureHelper.create("CaptureThread", eglBase.eglBaseContext)

        videoCapturer = createCameraCapturer()
        videoCapturer?.initialize(surfaceHelper, context, videoSource.capturerObserver)
        // LOW RESOLUTION + LOW FRAMERATE - keeps latency and mobile data usage down
        videoCapturer?.startCapture(320, 240, 15)

        localVideoTrack = peerConnectionFactory.createVideoTrack("robot_video", videoSource)
        localVideoTrack?.addSink(openCvAnalyzer)
    }

    private fun createCameraCapturer(): VideoCapturer? {
        val enumerator = Camera2Enumerator(context)
        for (deviceName in enumerator.deviceNames) {
            if (enumerator.isBackFacing(deviceName)) {
                enumerator.createCapturer(deviceName, null)?.let { return it }
            }
        }
        // fallback to any camera if no back-facing one found
        enumerator.deviceNames.firstOrNull()?.let {
            return enumerator.createCapturer(it, null)
        }
        return null
    }

    private fun createPeerConnectionAndOffer() {
        val rtcConfig = PeerConnection.RTCConfiguration(iceServers)
        peerConnection = peerConnectionFactory.createPeerConnection(rtcConfig, object : PeerConnection.Observer {
            override fun onIceCandidate(candidate: IceCandidate) {
                val map = hashMapOf(
                    "sdpMid" to candidate.sdpMid,
                    "sdpMLineIndex" to candidate.sdpMLineIndex,
                    "candidate" to candidate.sdp
                )
                callDocRef.collection("offerCandidates").add(map)
            }
            override fun onSignalingChange(state: PeerConnection.SignalingState) {}
            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState) {}
            override fun onIceConnectionReceivingChange(receiving: Boolean) {}
            override fun onIceGatheringChange(state: PeerConnection.IceGatheringState) {}
            override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>) {}
            override fun onAddStream(stream: MediaStream) {}
            override fun onRemoveStream(stream: MediaStream) {}
            override fun onDataChannel(channel: DataChannel) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(receiver: RtpReceiver, streams: Array<out MediaStream>) {}
        })

        val streamIds = listOf("robot_stream")
        localVideoTrack?.let { peerConnection?.addTrack(it, streamIds) }

        val constraints = MediaConstraints()
        peerConnection?.createOffer(object : SdpObserverAdapter() {
            override fun onCreateSuccess(desc: SessionDescription?) {
                peerConnection?.setLocalDescription(SdpObserverAdapter(), desc)
                val offerMap = hashMapOf("type" to desc?.type?.canonicalForm(), "sdp" to desc?.description)
                callDocRef.set(mapOf("offer" to offerMap))
            }
        }, constraints)
    }

    private fun listenForAnswerAndIce() {
        callDocRef.addSnapshotListener { snapshot, _ ->
            val data = snapshot?.data ?: return@addSnapshotListener
            val answerMap = data["answer"] as? Map<*, *> ?: return@addSnapshotListener
            if (peerConnection?.remoteDescription == null) {
                val desc = SessionDescription(
                    SessionDescription.Type.ANSWER,
                    answerMap["sdp"] as String
                )
                peerConnection?.setRemoteDescription(SdpObserverAdapter(), desc)
            }
        }

        callDocRef.collection("answerCandidates").addSnapshotListener { snapshot, _ ->
            snapshot?.documentChanges?.forEach { change ->
                if (change.type == com.google.firebase.firestore.DocumentChange.Type.ADDED) {
                    val d = change.document
                    val candidate = IceCandidate(
                        d.getString("sdpMid"),
                        (d.getLong("sdpMLineIndex") ?: 0L).toInt(),
                        d.getString("candidate")
                    )
                    peerConnection?.addIceCandidate(candidate)
                }
            }
        }
    }

    fun stop() {
        videoCapturer?.stopCapture()
        videoCapturer?.dispose()
        peerConnection?.close()
    }

    /** Call after start() to show the local camera feed on-screen (e.g. in a
     *  org.webrtc.SurfaceViewRenderer placed in your layout). Safe to call even
     *  if you never connect to a dashboard viewer - purely local preview. */
    fun attachLocalRenderer(renderer: org.webrtc.SurfaceViewRenderer) {
        renderer.init(eglBase.eglBaseContext, null)
        localVideoTrack?.addSink(renderer)
    }
}

/** SdpObserver has 4 methods we usually don't need all of - this adapter avoids boilerplate. */
open class SdpObserverAdapter : SdpObserver {
    override fun onCreateSuccess(desc: SessionDescription?) {}
    override fun onSetSuccess() {}
    override fun onCreateFailure(error: String?) {}
    override fun onSetFailure(error: String?) {}
}
